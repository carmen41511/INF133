--Readme document for *Carmen Liang*--

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

10/10
1 */1 Tweet dates
1 */1 Tweet categories
1 */1 User-written tweets
1 */2 Determining activity type and distance
2 */2 Graphing activities by distance
1 */1 Implementing the search box
1 */2 Populating the table

2. How long, in hours, did it take you to complete this assignment?

20 hours

3. What online resources did you consult when completing this assignment? (list sites like StackOverflow or specific URLs for tutorials, etc.)

https://www.w3schools.com/jsref/jsref_includes.asp
https://thispointer.com/javascript-remove-everything-after-a-certain-character/
https://l.facebook.com/l.php?u=https%3A%2F%2Fwww.geeksforgeeks.org%2Fjavascript-date-tolocaledatestring-method%2F%3Ffbclid%3DIwAR3voO-nMzVjUvg0JYDT6lNlEjy3k3Ys3FZgm_fWalygBNdIav3gFroBsOc&h=AT3bp9r8TkmqMeNxWMwkyxSvFcKS24_JL9K13reL01QK5ortlzHvpQwhhx90fXr0Tg4TBLHzz2bixw71UdXJfKiwQL344lRUHyEKJ0DcAnrucRTNR7EKkMZW4O8CR7K5_zKhWQ
https://stackoverflow.com/questions/45163256/how-to-format-numbers-as-percentage-values-in-javascript
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Regular_Expressions
https://stackoverflow.com/questions/10023845/regex-in-javascript-for-validating-decimal-numbers/31737906
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/match
https://regex101.com/
https://stackoverflow.com/questions/58132494/how-to-find-second-most-frequent-element-in-an-array-i-have-found-most-frequent
https://vega.github.io/vega-lite/examples/layer_ranged_dot.html

4. What classmates or other individuals did you consult as part of this assignment? What did you discuss?



5. Is there anything special we need to know in order to run your code?

I wrote the code for activities.js, but the graph isn't showing.. Please take a look at the code the provide a fair scoring :) !