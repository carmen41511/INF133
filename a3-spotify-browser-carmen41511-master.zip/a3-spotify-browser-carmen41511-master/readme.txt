--Readme document for *author(s)*, *email(s)*, *UCI id(s)*--

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

*/10
- */1 Communicating with the webserver
- */1 Populating information about the user
- */3 Populating the search component
- */2 Artist page
- */1.5 Album page
- */1.5 Track page


2. How long, in hours, did it take you to complete this assignment?



3. What online resources did you consult when completing this assignment? (list specific URLs)

https://www.youtube.com/watch?v=Mz8lb81AAe4
https://www.youtube.com/watch?v=DYNzLRsixeo
https://www.youtube.com/watch?v=Du3p6QYGs3A
https://www.youtube.com/watch?v=8ZlrORYOl_0
https://www.youtube.com/watch?v=4fKa13TTn7E
https://stackoverflow.com/questions/45428659/how-to-pull-value-out-of-promise
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise/then

4. What classmates or other individuals did you consult as part of this assignment? What did you discuss?



5. Did you add a bonus feature to your submission? If so, what is it and how should we see it?



6. Is there anything special we need to know in order to run your code?

